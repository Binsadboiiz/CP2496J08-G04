package controller.cashier;

import javafx.fxml.FXML;

public class CalculateSalaryController {
    @FXML
    private void calculateSalary() {
        // Logic để tính lương
    }

    @FXML
    private void viewSalaryHistory() {
        // Logic để xem lịch sử lương
    }
}
