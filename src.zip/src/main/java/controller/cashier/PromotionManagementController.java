package controller.cashier;

import javafx.fxml.FXML;

public class PromotionManagementController {
    @FXML
    private void addPromotion() {
        // Logic để thêm khuyến mãi
    }

    @FXML
    private void removePromotion() {
        // Logic để xóa khuyến mãi
    }

    @FXML
    private void updatePromotion() {
        // Logic để cập nhật khuyến mãi
    }
}
