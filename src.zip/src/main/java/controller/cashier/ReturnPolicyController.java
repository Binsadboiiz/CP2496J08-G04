package controller.cashier;

import javafx.fxml.FXML;

public class ReturnPolicyController {
    @FXML
    private void viewReturnPolicy() {
        // Logic để xem chính sách đổi trả
    }

    @FXML
    private void updateReturnPolicy() {
        // Logic để cập nhật chính sách đổi trả
    }
}
