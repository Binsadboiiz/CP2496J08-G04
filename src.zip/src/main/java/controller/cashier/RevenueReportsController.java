package controller.cashier;

import javafx.fxml.FXML;

public class RevenueReportsController {
    @FXML
    private void viewReports() {
        // Logic để xem báo cáo doanh thu
    }

    @FXML
    private void exportReports() {
        // Logic để xuất báo cáo doanh thu
    }
}
