package controller.staff;

import dao.CustomerDAO;
import javafx.scene.control.cell.PropertyValueFactory;
import model.Customer;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class CustomerManagementController {

    @FXML private TableView<Customer> customerTable;
    @FXML private TextField searchField, nameField, phoneField, typeField;
    @FXML private TableColumn<Customer, String> nameColumn;
    @FXML private TableColumn<Customer, String> phoneColumn;
    @FXML private TableColumn<Customer, String> typeColumn;

    private final CustomerDAO customerDAO = new CustomerDAO();
    private ObservableList<Customer> customers;

    @FXML
    public void initialize() {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("address")); // Tạm dùng address làm loại khách

        customers = FXCollections.observableArrayList(customerDAO.getAllCustomers());
        customerTable.setItems(customers);
    }

    @FXML
    public void addCustomer() {
        Customer c = new Customer();
        c.setFullName(nameField.getText());        // Sử dụng fullName thay cho name
        c.setPhone(phoneField.getText());
        c.setAddress(typeField.getText());         // Tạm dùng address để lưu loại khách
        customerDAO.insertCustomer(c);
        refresh();
    }

    @FXML
    public void editCustomer() {
        Customer selected = customerTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        selected.setFullName(nameField.getText()); // Sử dụng fullName thay cho name
        selected.setPhone(phoneField.getText());
        selected.setAddress(typeField.getText());  // Tạm dùng address để lưu loại khách
        customerDAO.updateCustomer(selected);
        refresh();
    }

    @FXML
    public void searchCustomer() {
        customers.setAll(customerDAO.searchCustomers(searchField.getText()));
    }

    @FXML
    private void refresh() {
        customers.setAll(customerDAO.getAllCustomers());
    }
}
