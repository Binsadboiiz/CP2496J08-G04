package controller.staff;

import dao.ProductDAO;
import model.Product;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;

import java.io.InputStream;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class HomeController {

    @FXML private FlowPane productGrid;
    @FXML private TextField searchField;

    private StaffController staffController;

    @FXML
    public void initialize() {
        loadProducts(ProductDAO.getAll());
    }

    public void setStaffController(StaffController staffController) {
        this.staffController = staffController;
    }

    @FXML
    private void handleSearch() {
        loadProducts(ProductDAO.search(searchField.getText()));
    }

    @FXML
    private void handleReset() {
        searchField.clear();
        loadProducts(ProductDAO.getAll());
    }

    private void loadProducts(List<Product> products) {
        productGrid.getChildren().clear();
        for (Product product : products) {
            productGrid.getChildren().add(createProductCard(product));
        }
    }

    private VBox createProductCard(Product product) {
        VBox card = new VBox(8);
        card.setAlignment(Pos.CENTER);
        card.setPrefSize(160, 250);
        card.setStyle("-fx-border-color: #ccc; -fx-border-radius: 10; -fx-background-radius: 10; -fx-padding: 12; -fx-background-color: #fff;");

        ImageView imageView = new ImageView();
        imageView.setImage(loadProductImage(product.getImage()));
        imageView.setFitWidth(120);
        imageView.setFitHeight(120);
        imageView.setPreserveRatio(true);

        Label nameLabel = new Label(product.getProductName());
        nameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");
        nameLabel.setWrapText(true);
        nameLabel.setMaxWidth(140);

        String priceStr = NumberFormat.getNumberInstance(new Locale("de", "DE"))
                .format(product.getPrice()) + " VND";
        Label priceLabel = new Label(priceStr);
        priceLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #e74c3c;");

        Button detailBtn = new Button("Details");
        detailBtn.setOnAction(e -> showProductDetails(product));

        Label stockLabel = new Label("Stock: " + product.getStockQuantity());
        stockLabel.setStyle("-fx-font-size: 13; -fx-text-fill: #27ae60; -fx-font-weight: bold;");

        card.getChildren().addAll(imageView, nameLabel, priceLabel, detailBtn, stockLabel);
        return card;
    }

    private Image loadProductImage(String imgName) {
        try {
            if (imgName != null && !imgName.isEmpty()) {
                if (imgName.startsWith("http://") || imgName.startsWith("https://")) {
                    return new Image(imgName, 120, 120, true, true);
                } else if (imgName.startsWith("/") || imgName.matches("^[A-Za-z]:.*")) {
                    return new Image("file:///" + imgName.replace("\\", "/"), 120, 120, true, true);
                } else {
                    InputStream imageStream = getClass().getResourceAsStream("/images/" + imgName);
                    if (imageStream != null) {
                        return new Image(imageStream, 120, 120, true, true);
                    }
                }
            }
        } catch (Exception ignored) {}

        // Fallback image
        InputStream fallback = getClass().getResourceAsStream("/images/register_logo.png");
        return (fallback != null) ? new Image(fallback, 120, 120, true, true) : null;
    }

    private void showProductDetails(Product product) {
        VBox content = new VBox(10);
        content.setAlignment(Pos.CENTER);
        content.setStyle("-fx-padding: 20;");

        NumberFormat format = NumberFormat.getNumberInstance(new Locale("de", "DE"));
        String priceStr = format.format(product.getPrice()) + " VND";

        content.getChildren().addAll(
                new Label("Name: " + product.getProductName()),
                new Label("Code: " + product.getProductCode()),
                new Label("Brand: " + product.getBrand()),
                new Label("Type: " + product.getType()),
                new Label("Price: " + priceStr),
                new Label("Description: " + product.getDescription())
        );

        Stage stage = new Stage();
        stage.setScene(new Scene(content, 350, 300));
        stage.setTitle("Product Details");
        stage.show();
    }

    private void addToInvoice(Product product) {
        CreateInvoiceController.addProductToInvoice(product);

        if (staffController != null) {
            try {
                staffController.loadCreateInvoice();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            new Alert(Alert.AlertType.ERROR, "Cannot navigate to invoice screen. Please try again.").showAndWait();
        }
    }
}
