package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InventoryDAO {
    public static int getStockAlerts(int threshold) {
        String sql = "SELECT COUNT(*) FROM Inventory WHERE Quantity <= ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, threshold);
            ResultSet rs = ps.executeQuery();
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    // Hàm mới để lấy số lượng tồn theo ID sản phẩm
    public static int getQuantityByProductId(int productId) {
        int quantity = 0;
        String sql = "SELECT Quantity FROM Inventory WHERE ProductID = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, productId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                quantity = rs.getInt("Quantity");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return quantity;
    }
}
