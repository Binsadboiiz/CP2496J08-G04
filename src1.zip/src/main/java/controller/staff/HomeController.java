package controller.staff;

import dao.ProductDAO;
import model.Product;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;


import java.util.List;

public class HomeController {
    @FXML private FlowPane productGrid;
    @FXML private TextField searchField;


    @FXML
    public void initialize() {
        loadProducts(ProductDAO.getAll());
    }

    private void loadProducts(List<Product> products) {
        productGrid.getChildren().clear();
        for (Product p : products) {
            VBox card = createProductCard(p);
            productGrid.getChildren().add(card);
        }
    }

    private VBox createProductCard(Product product) {
        VBox card = new VBox(5);
        card.setAlignment(Pos.CENTER);
        card.setPrefSize(160, 240);
        card.setStyle("-fx-border-color: #ccc; -fx-border-radius: 8; -fx-background-radius: 8; -fx-padding: 10;");

        ImageView img = new ImageView();
        try {
            img.setImage(new Image(product.getImage() != null ? product.getImage() : "/images/iphone15.png",
                    120, 120, true, true));
        } catch (Exception e) {
            img.setImage(new Image("/images/iphone15.png", 120, 120, true, true));
        }

        Label name = new Label(product.getProductName());
        name.setStyle("-fx-font-weight: bold; -fx-font-size: 14; -fx-text-alignment: center;");
        Label price = new Label(product.getPrice() + " VND");

        Button detailBtn = new Button("Chi tiết");
        detailBtn.setOnAction(e -> showProductDetail(product));

        Button addBtn = new Button("Thêm vào hóa đơn");
        addBtn.setOnAction(e -> addToInvoice(product));

        card.getChildren().addAll(img, name, price, detailBtn, addBtn);
        return card;
    }

    private void showProductDetail(Product product) {
        Stage stage = new Stage();
        VBox box = new VBox(10);
        box.setAlignment(Pos.CENTER);
        box.setStyle("-fx-padding: 20;");
        box.getChildren().addAll(
                new Label("Tên: " + product.getProductName()),
                new Label("Mã: " + product.getProductCode()),
                new Label("Hãng: " + product.getBrand()),
                new Label("Loại: " + product.getType()),
                new Label("Giá: " + product.getPrice() + " VND"),
                new Label("Mô tả: " + product.getDescription())
        );
        stage.setScene(new Scene(box, 350, 300));
        stage.setTitle("Chi tiết sản phẩm");
        stage.show();
    }

    private void addToInvoice(Product product) {
        CreateInvoiceController.addProductToInvoice(product);
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Đã thêm " + product.getProductName() + " vào hóa đơn!");
        alert.showAndWait();
    }

    @FXML
    private void handleSearch() {
        String keyword = searchField.getText();
        loadProducts(ProductDAO.search(keyword));
    }

    @FXML
    private void handleReset() {
        searchField.clear();
        loadProducts(ProductDAO.getAll());
    }
}
