package controller.staff;

import dao.CustomerDAO;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Customer;
import model.Product;
import dao.InvoiceDAO;
import dao.InvoiceDetailDAO;
import dao.ProductDAO;
import dao.InventoryDAO;
import model.Invoice;
import model.InvoiceDetail;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import dao.PromotionDAO;
import model.Promotion;
import javafx.util.StringConverter;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.File;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.scene.control.CheckBox;
import javafx.application.Platform;

public class CreateInvoiceController {

    @FXML private ListView<Promotion> promotionListView;
    private final ObservableList<Promotion> selectedPromotions = FXCollections.observableArrayList();

    @FXML private ComboBox<Product> productComboBox;
    @FXML private TextField quantityField;
    @FXML private TextField discountField;
    @FXML private TableView<InvoiceItem> invoiceTable;
    @FXML private TableColumn<InvoiceItem, String> productNameColumn;
    @FXML private TableColumn<InvoiceItem, Integer> quantityColumn;
    @FXML private TableColumn<InvoiceItem, Double> priceColumn;
    @FXML private TableColumn<InvoiceItem, Double> totalColumn;
    @FXML private Label totalLabel;
    @FXML private ComboBox<Customer> customerComboBox;
    @FXML private Label stockLabel;

    private ObservableList<InvoiceItem> invoiceItems = FXCollections.observableArrayList();
    private ObservableList<Customer> allCustomers = FXCollections.observableArrayList();
    private ObservableList<Product> allProducts = FXCollections.observableArrayList();

    private final CustomerDAO customerDAO = new CustomerDAO();
    private final InvoiceDAO invoiceDAO = new InvoiceDAO();
    private final InvoiceDetailDAO invoiceDetailDAO = new InvoiceDetailDAO();
    private final NumberFormat numberFormat = NumberFormat.getNumberInstance(new Locale("vi", "VN"));

    private StaffController staffController;
    private static ObservableList<Product> selectedProducts = FXCollections.observableArrayList();

    public void setStaffController(StaffController staffController) {
        this.staffController = staffController;
    }

    public static void addProductToInvoice(Product product) {
        selectedProducts.add(product);
    }

    @FXML
    public void initialize() {
        numberFormat.setGroupingUsed(true);

        loadCustomers();
        loadProducts();
        setupCustomerFeatures();
        setupProductFeatures();
        setupTableColumns();
        setupPromotionList();

        // Add pre-selected products if any
        if (!selectedProducts.isEmpty()) {
            for (Product product : selectedProducts) {
                invoiceItems.add(new InvoiceItem(product.getProductName(), 1, product.getPrice(), product.getProductID()));
            }
            selectedProducts.clear();
        }

        invoiceTable.setItems(invoiceItems);
        calculateAndDisplayTotal();
    }

    private void setupTableColumns() {
        productNameColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("productName"));
        quantityColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("quantity"));

        priceColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("price"));
        priceColumn.setCellFactory(tc -> new TableCell<InvoiceItem, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                setText(empty || price == null ? null : numberFormat.format(price) + " VND");
            }
        });

        totalColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("total"));
        totalColumn.setCellFactory(tc -> new TableCell<InvoiceItem, Double>() {
            @Override
            protected void updateItem(Double total, boolean empty) {
                super.updateItem(total, empty);
                setText(empty || total == null ? null : numberFormat.format(total) + " VND");
            }
        });
    }

    private void setupPromotionList() {
        try {
            List<Promotion> promotionList = PromotionDAO.getAll();

            if (promotionListView != null) {
                if (promotionList == null || promotionList.isEmpty()) {
                    // Create empty list with simple message
                    ObservableList<Promotion> emptyPromotions = FXCollections.observableArrayList();
                    promotionListView.setItems(emptyPromotions);

                    // Simple cell factory for empty state
                    promotionListView.setCellFactory(lv -> new ListCell<Promotion>() {
                        @Override
                        protected void updateItem(Promotion item, boolean empty) {
                            super.updateItem(item, empty);
                            if (empty || item == null) {
                                setText("No promotions available");
                                setGraphic(null);
                                setDisable(true);
                                setStyle("-fx-text-fill: gray;");
                            } else {
                                setText(null);
                                setGraphic(null);
                            }
                        }
                    });

                    // Disable mouse events on empty list
                    promotionListView.setDisable(true);

                    // COMPLETELY disable selection model for empty list
                    promotionListView.setMouseTransparent(true);
                    promotionListView.setFocusTraversable(false);
                } else {
                    // Enable the list
                    promotionListView.setDisable(false);
                    promotionListView.setMouseTransparent(false);
                    promotionListView.setFocusTraversable(true);

                    ObservableList<Promotion> allPromotions = FXCollections.observableArrayList(promotionList);
                    promotionListView.setItems(allPromotions);

                    // Create custom cell with checkbox - SAFE version
                    promotionListView.setCellFactory(lv -> new ListCell<Promotion>() {
                        private CheckBox checkBox;
                        private Promotion currentPromotion;

                        {
                            checkBox = new CheckBox();
                            checkBox.setOnAction(e -> {
                                if (currentPromotion != null) {
                                    try {
                                        if (checkBox.isSelected()) {
                                            if (!selectedPromotions.contains(currentPromotion)) {
                                                selectedPromotions.add(currentPromotion);
                                            }
                                        } else {
                                            selectedPromotions.remove(currentPromotion);
                                        }
                                        applyPromotionDiscounts();
                                    } catch (Exception ex) {
                                        System.err.println("Error in checkbox action: " + ex.getMessage());
                                    }
                                }
                            });
                        }

                        @Override
                        protected void updateItem(Promotion item, boolean empty) {
                            super.updateItem(item, empty);

                            if (empty || item == null) {
                                setText(null);
                                setGraphic(null);
                                currentPromotion = null;
                            } else {
                                currentPromotion = item;
                                checkBox.setText(item.getPromotionName() + " (" + item.getDiscountPercentage() + "%)");
                                checkBox.setSelected(selectedPromotions.contains(item));
                                setGraphic(checkBox);
                                setText(null);
                            }
                        }
                    });
                }

                // COMPLETELY DISABLE ListView selection behavior
                try {
                    // Disable selection behavior entirely
                    promotionListView.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
                        // Prevent any selection
                        if (newVal != null) {
                            Platform.runLater(() -> {
                                try {
                                    promotionListView.getSelectionModel().clearSelection();
                                } catch (Exception ignored) {}
                            });
                        }
                    });

                    // Clear any initial selection
                    Platform.runLater(() -> {
                        try {
                            promotionListView.getSelectionModel().clearSelection();
                        } catch (Exception ignored) {}
                    });

                } catch (Exception e) {
                    System.err.println("Could not disable selection model: " + e.getMessage());
                }
            }
        } catch (Exception e) {
            System.err.println("Error setting up promotion list: " + e.getMessage());
            e.printStackTrace();

            // Ultimate fallback
            if (promotionListView != null) {
                try {
                    promotionListView.setItems(FXCollections.observableArrayList());
                    promotionListView.setDisable(true);
                    promotionListView.setMouseTransparent(true);
                    promotionListView.setFocusTraversable(false);
                    promotionListView.setCellFactory(lv -> new ListCell<Promotion>() {
                        @Override
                        protected void updateItem(Promotion item, boolean empty) {
                            super.updateItem(item, empty);
                            setText("Error loading promotions");
                            setGraphic(null);
                            setDisable(true);
                        }
                    });
                } catch (Exception fallbackEx) {
                    System.err.println("Critical error in promotion list fallback: " + fallbackEx.getMessage());
                }
            }
        }
    }

    private void loadCustomers() {
        try {
            List<Customer> customerList = customerDAO.getAllCustomers();
            allCustomers.setAll(customerList);
        } catch (Exception e) {
            System.err.println("Error loading customers: " + e.getMessage());
        }
    }

    private void loadProducts() {
        try {
            List<Product> productList = ProductDAO.getAll();

            // Log để kiểm tra stock
            System.out.println("All products: " + productList.size());
            for (Product p : productList) {
                int stock = InventoryDAO.getCurrentStock(p.getProductID());
                System.out.println(p.getProductName() + " stock = " + stock);
            }

            // Bỏ filter stock để test
            allProducts.setAll(productList);

        } catch (Exception e) {
            System.err.println("Error loading products: " + e.getMessage());
        }
    }

    private void setupCustomerFeatures() {
        customerComboBox.setEditable(true);
        customerComboBox.setItems(allCustomers);

        customerComboBox.setConverter(new StringConverter<Customer>() {
            @Override
            public String toString(Customer customer) {
                return customer != null ? customer.getFullName() : "";
            }

            @Override
            public Customer fromString(String string) {
                return allCustomers.stream()
                        .filter(customer -> customer.getFullName().equals(string))
                        .findFirst()
                        .orElse(null);
            }
        });

        customerComboBox.getEditor().textProperty().addListener((obs, oldText, newText) -> {
            if (newText == null || newText.isEmpty()) {
                customerComboBox.setItems(allCustomers);
            } else {
                ObservableList<Customer> filteredCustomers = allCustomers.stream()
                        .filter(customer -> customer.getFullName().toLowerCase()
                                .contains(newText.toLowerCase()))
                        .collect(Collectors.toCollection(FXCollections::observableArrayList));
                customerComboBox.setItems(filteredCustomers);
            }

            if (!customerComboBox.isShowing() && !newText.isEmpty()) {
                customerComboBox.show();
            }
        });
    }

    private void setupProductFeatures() {
        productComboBox.setEditable(true);
        productComboBox.setItems(allProducts);

        productComboBox.setConverter(new StringConverter<Product>() {
            @Override
            public String toString(Product product) {
                if (product != null) {
                    int stock = InventoryDAO.getCurrentStock(product.getProductID());
                    return product.getProductName() + " - " + numberFormat.format(product.getPrice()) + " VND (Stock: " + stock + ")";
                }
                return "";
            }

            @Override
            public Product fromString(String string) {
                return allProducts.stream()
                        .filter(product -> {
                            int stock = InventoryDAO.getCurrentStock(product.getProductID());
                            String productString = product.getProductName() + " - " + numberFormat.format(product.getPrice()) + " VND (Stock: " + stock + ")";
                            return productString.equals(string);
                        })
                        .findFirst()
                        .orElse(null);
            }
        });

        productComboBox.getEditor().textProperty().addListener((obs, oldText, newText) -> {
            if (newText == null || newText.isEmpty()) {
                productComboBox.setItems(allProducts);
            } else {
                ObservableList<Product> filteredProducts = allProducts.stream()
                        .filter(product -> product.getProductName().toLowerCase().contains(newText.toLowerCase()) ||
                                product.getProductCode().toLowerCase().contains(newText.toLowerCase()))
                        .collect(Collectors.toCollection(FXCollections::observableArrayList));
                productComboBox.setItems(filteredProducts);
            }

            if (!productComboBox.isShowing() && !newText.isEmpty()) {
                productComboBox.show();
            }
        });

        productComboBox.setCellFactory(lv -> new ListCell<Product>() {
            @Override
            protected void updateItem(Product product, boolean empty) {
                super.updateItem(product, empty);
                if (empty || product == null) {
                    setText(null);
                } else {
                    int stock = InventoryDAO.getCurrentStock(product.getProductID());
                    setText(product.getProductName() + " - " + numberFormat.format(product.getPrice()) + " VND (Stock: " + stock + ")");

                    if (stock <= 0) {
                        setDisable(true);
                        setStyle("-fx-text-fill: gray;");
                    } else {
                        setDisable(false);
                        setStyle("");
                    }
                }
            }
        });

        productComboBox.getSelectionModel().selectedItemProperty().addListener((obs, oldProduct, newProduct) -> {
            updateStockLabel(newProduct);
        });
    }

    private void updateStockLabel(Product product) {
        if (product != null) {
            int currentStock = InventoryDAO.getCurrentStock(product.getProductID());
            if (currentStock > 0) {
                stockLabel.setText("Stock: " + numberFormat.format(currentStock) + " items");
                stockLabel.setStyle("-fx-font-size: 12px; -fx-font-style: italic; -fx-text-fill: green;");
            } else {
                stockLabel.setText("Out of stock");
                stockLabel.setStyle("-fx-font-size: 12px; -fx-font-style: italic; -fx-text-fill: red;");
            }
        } else {
            stockLabel.setText("Select product to view stock");
            stockLabel.setStyle("-fx-font-size: 12px; -fx-font-style: italic;");
        }
    }

    @FXML
    private void handleAddProduct() {
        Product selectedProduct = productComboBox.getSelectionModel().getSelectedItem();

        if (selectedProduct == null) {
            showAlert("Error", "Please select a product.");
            return;
        }

        int currentStock = InventoryDAO.getCurrentStock(selectedProduct.getProductID());
        if (currentStock <= 0) {
            showAlert("Error", "This product is out of stock!");
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityField.getText());
        } catch (NumberFormatException e) {
            showAlert("Error", "Quantity must be a valid number.");
            return;
        }

        if (quantity <= 0) {
            showAlert("Error", "Quantity must be greater than 0.");
            return;
        }

        if (quantity > currentStock) {
            showAlert("Error", "Requested quantity (" + numberFormat.format(quantity) + ") exceeds available stock (" +
                    numberFormat.format(currentStock) + ").\nPlease enter a quantity less than or equal to " +
                    numberFormat.format(currentStock) + ".");
            return;
        }

        // Check if product already exists in invoice
        boolean productExists = false;
        for (InvoiceItem existingItem : invoiceItems) {
            if (existingItem.getProductID() == selectedProduct.getProductID()) {
                int totalQuantityAfterAdd = existingItem.getQuantity() + quantity;
                if (totalQuantityAfterAdd > currentStock) {
                    showAlert("Error", "Total quantity of product '" + selectedProduct.getProductName() + "' will be " +
                            numberFormat.format(totalQuantityAfterAdd) + ", exceeding available stock (" +
                            numberFormat.format(currentStock) + ").\nCurrently in invoice: " +
                            numberFormat.format(existingItem.getQuantity()) + " items.");
                    return;
                }

                InvoiceItem updatedItem = new InvoiceItem(existingItem.getProductName(), totalQuantityAfterAdd,
                        existingItem.getPrice(), existingItem.getProductID());
                int index = invoiceItems.indexOf(existingItem);
                invoiceItems.set(index, updatedItem);
                productExists = true;
                break;
            }
        }

        if (!productExists) {
            invoiceItems.add(new InvoiceItem(selectedProduct.getProductName(), quantity,
                    selectedProduct.getPrice(), selectedProduct.getProductID()));
        }

        clearProductSelection();
        calculateAndDisplayTotal();
        loadProducts();
    }

    private void clearProductSelection() {
        productComboBox.getSelectionModel().clearSelection();
        productComboBox.getEditor().clear();
        quantityField.clear();
        stockLabel.setText("Select product to view stock");
        stockLabel.setStyle("-fx-font-size: 12px; -fx-font-style: italic;");
    }

    @FXML
    private void handleRemoveProduct() {
        InvoiceItem selectedItem = invoiceTable.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            invoiceItems.remove(selectedItem);
            calculateAndDisplayTotal();
            loadProducts();
        } else {
            showAlert("Notice", "Please select a product to remove.");
        }
    }

    @FXML
    private void handleCalculateTotal() {
        calculateAndDisplayTotal();
    }

    private void calculateAndDisplayTotal() {
        BigDecimal subTotal = invoiceItems.stream()
                .map(item -> BigDecimal.valueOf(item.getTotal()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        double totalDiscount = getManualDiscount() + getPromotionDiscount();
        BigDecimal discountMultiplier = BigDecimal.ONE.subtract(BigDecimal.valueOf(totalDiscount).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
        BigDecimal total = subTotal.multiply(discountMultiplier).setScale(0, RoundingMode.HALF_UP);

        String formattedTotal = numberFormat.format(total.doubleValue());
        totalLabel.setText("Total: " + formattedTotal + " VND");
    }

    private double getManualDiscount() {
        if (discountField.getText().isEmpty()) return 0.0;
        try {
            return Double.parseDouble(discountField.getText());
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private double getPromotionDiscount() {
        return selectedPromotions.stream().mapToDouble(Promotion::getDiscountPercentage).sum();
    }

    private void applyPromotionDiscounts() {
        try {
            double totalPromotionDiscount = getPromotionDiscount();
            double manualDiscount = getManualDiscount();

            // Update discount field to show combined discount
            discountField.setText(String.valueOf(manualDiscount + totalPromotionDiscount));
            calculateAndDisplayTotal();
        } catch (Exception e) {
            System.err.println("Error applying promotion discounts: " + e.getMessage());
        }
    }

    @FXML
    private void handleSaveInvoice() {
        Customer selectedCustomer = customerComboBox.getSelectionModel().getSelectedItem();

        if (selectedCustomer == null) {
            showAlert("Error", "Please select a customer.");
            return;
        }

        if (invoiceItems.isEmpty()) {
            showAlert("Error", "Please add at least one product to the invoice.");
            return;
        }

        // Validate stock before saving
        for (InvoiceItem item : invoiceItems) {
            int currentStock = InventoryDAO.getCurrentStock(item.getProductID());
            if (item.getQuantity() > currentStock) {
                showAlert("Error", "Product '" + item.getProductName() + "' has insufficient stock. Only " + currentStock + " items available.");
                return;
            }
        }

        Invoice newInvoice = createInvoice(selectedCustomer);
        int newInvoiceID = invoiceDAO.insertInvoice(newInvoice);

        if (newInvoiceID > 0) {
            saveInvoiceDetails(newInvoiceID);
            String filePath = exportInvoiceToTxt(newInvoice, newInvoiceID, selectedCustomer);

            showAlert("Success", filePath != null ?
                    "Invoice has been created and saved successfully!\nFile exported to: " + filePath :
                    "Invoice has been created and saved successfully!\n(File export failed - check console for details)");

            if (staffController != null) {
                try {
                    staffController.loadInvoiceHistory();
                } catch (Exception e) {
                    e.printStackTrace();
                    showAlert("Error", "Unable to navigate to Invoice History page.");
                }
            }
        } else {
            showAlert("Error", "Unable to save invoice. Please check again.");
        }
    }

    private Invoice createInvoice(Customer customer) {
        Invoice invoice = new Invoice();
        invoice.setCustomerID(customer.getCustomerID());
        invoice.setUserID(1); // TODO: Get actual staff ID from login session
        invoice.setDate(LocalDateTime.now());
        invoice.setTotalAmount(BigDecimal.valueOf(calculateTotalAmount()));
        invoice.setDiscount(BigDecimal.valueOf(getManualDiscount() + getPromotionDiscount()));
        invoice.setStatus("Complete");
        return invoice;
    }

    private void saveInvoiceDetails(int invoiceID) {
        for (InvoiceItem item : invoiceItems) {
            InvoiceDetail detail = new InvoiceDetail(invoiceID, item.getProductID(), item.getQuantity(),
                    BigDecimal.valueOf(item.getPrice()), BigDecimal.ZERO);
            invoiceDetailDAO.insertInvoiceDetail(detail);
        }
    }

    private String exportInvoiceToTxt(Invoice invoice, int invoiceID, Customer customer) {
        try {
            String fileName = getExportFileName("invoice_" + invoiceID + ".txt");
            File file = new File(fileName);

            try (FileWriter fileWriter = new FileWriter(file);
                 PrintWriter printWriter = new PrintWriter(fileWriter)) {

                writeInvoiceHeader(printWriter, invoiceID, invoice, customer);
                writeInvoiceItems(printWriter);
                writeInvoiceFooter(printWriter);
            }

            return file.exists() ? file.getAbsolutePath() : null;
        } catch (IOException e) {
            System.err.println("Unable to export invoice to file: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    private String getExportFileName(String fileName) {
        String desktopPath = System.getProperty("user.home") + File.separator + "Desktop";
        File desktopDir = new File(desktopPath);

        if (desktopDir.exists() && desktopDir.canWrite()) {
            return desktopPath + File.separator + fileName;
        } else {
            return System.getProperty("user.home") + File.separator + "Documents" + File.separator + fileName;
        }
    }

    private void writeInvoiceHeader(PrintWriter printWriter, int invoiceID, Invoice invoice, Customer customer) {
        printWriter.println("===========================================");
        printWriter.println("            SALES INVOICE");
        printWriter.println("===========================================");
        printWriter.println("Invoice ID: " + invoiceID);
        printWriter.println("Date: " + invoice.getDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));
        printWriter.println("Customer: " + customer.getFullName());
        printWriter.println("Email: " + (customer.getEmail() != null ? customer.getEmail() : "N/A"));
        printWriter.println("===========================================");
        printWriter.println();
    }

    private void writeInvoiceItems(PrintWriter printWriter) {
        printWriter.println("PRODUCT DETAILS:");
        printWriter.println("-------------------------------------------");
        printWriter.printf("%-30s %-10s %-15s %-15s%n", "Product Name", "Qty", "Unit Price", "Amount");
        printWriter.println("-------------------------------------------");

        double subTotal = 0;
        for (InvoiceItem item : invoiceItems) {
            printWriter.printf("%-30s %-10d %-15s %-15s%n",
                    item.getProductName(), item.getQuantity(),
                    numberFormat.format(item.getPrice()) + " VND",
                    numberFormat.format(item.getTotal()) + " VND");
            subTotal += item.getTotal();
        }

        printWriter.println("-------------------------------------------");
        printWriter.printf("%-30s %-10s %-15s %-15s%n", "SUBTOTAL", "", "", numberFormat.format(subTotal) + " VND");

        if (!selectedPromotions.isEmpty()) {
            printWriter.println();
            printWriter.println("APPLIED PROMOTIONS:");
            for (Promotion promo : selectedPromotions) {
                printWriter.println("- " + promo.getPromotionName() + ": " + promo.getDiscountPercentage() + "%");
            }
        }

        double totalDiscount = getManualDiscount() + getPromotionDiscount();
        if (totalDiscount > 0) {
            double discountAmount = subTotal * (totalDiscount / 100);
            printWriter.printf("%-30s %-10s %-15s %-15s%n", "Discount (" + totalDiscount + "%)", "", "",
                    "-" + numberFormat.format(discountAmount) + " VND");
        }

        printWriter.printf("%-30s %-10s %-15s %-15s%n", "TOTAL AMOUNT", "", "",
                numberFormat.format(calculateTotalAmount()) + " VND");
    }

    private void writeInvoiceFooter(PrintWriter printWriter) {
        printWriter.println("===========================================");
        printWriter.println("        Thank you for your business!");
        printWriter.println("===========================================");
    }

    @FXML
    private void handleExportCurrentInvoice() {
        Customer selectedCustomer = customerComboBox.getSelectionModel().getSelectedItem();

        if (selectedCustomer == null) {
            showAlert("Error", "Please select a customer.");
            return;
        }

        if (invoiceItems.isEmpty()) {
            showAlert("Error", "Please add at least one product to export.");
            return;
        }

        try {
            String fileName = getExportFileName("current_invoice_" + System.currentTimeMillis() + ".txt");
            File file = new File(fileName);

            try (FileWriter fileWriter = new FileWriter(file);
                 PrintWriter printWriter = new PrintWriter(fileWriter)) {

                printWriter.println("===========================================");
                printWriter.println("         SALES INVOICE (DRAFT)");
                printWriter.println("===========================================");
                printWriter.println("Date: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));
                printWriter.println("Customer: " + selectedCustomer.getFullName());
                printWriter.println("Email: " + (selectedCustomer.getEmail() != null ? selectedCustomer.getEmail() : "N/A"));
                printWriter.println("===========================================");
                printWriter.println();

                writeInvoiceItems(printWriter);
                writeInvoiceFooter(printWriter);
            }

            showAlert("Success", file.exists() ?
                    "Invoice exported successfully to: " + file.getAbsolutePath() :
                    "File was not created successfully");

        } catch (IOException e) {
            showAlert("Error", "Unable to export invoice: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleReset() {
        try {
            invoiceItems.clear();
            discountField.clear();
            totalLabel.setText("Total: 0 VND");
            customerComboBox.getSelectionModel().clearSelection();
            customerComboBox.getEditor().clear();
            clearProductSelection();
            selectedPromotions.clear();

            // Safely reset promotion list by creating a completely new one
            if (promotionListView != null) {
                // First, completely disable and clear everything
                promotionListView.setDisable(true);
                promotionListView.setMouseTransparent(true);
                promotionListView.setFocusTraversable(false);

                // Clear items safely
                try {
                    promotionListView.setItems(FXCollections.observableArrayList());
                } catch (Exception e) {
                    System.err.println("Could not clear promotion items: " + e.getMessage());
                }

                // Wait a bit then rebuild
                Platform.runLater(() -> {
                    try {
                        // Rebuild the promotion list from scratch
                        setupPromotionList();
                    } catch (Exception e) {
                        System.err.println("Error rebuilding promotion list: " + e.getMessage());
                        // Keep it disabled if rebuild fails
                        try {
                            promotionListView.setItems(FXCollections.observableArrayList());
                            promotionListView.setDisable(true);
                            promotionListView.setMouseTransparent(true);
                        } catch (Exception ex) {
                            System.err.println("Critical error in promotion list reset: " + ex.getMessage());
                        }
                    }
                });
            }

            loadProducts();
        } catch (Exception e) {
            System.err.println("Error in handleReset: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private double calculateTotalAmount() {
        double subTotal = invoiceItems.stream().mapToDouble(InvoiceItem::getTotal).sum();
        double totalDiscount = getManualDiscount() + getPromotionDiscount();
        return subTotal - subTotal * (totalDiscount / 100);
    }

    // Inner class for invoice items
    public static class InvoiceItem {
        private final String productName;
        private final int quantity;
        private final double price;
        private final int productID;

        public InvoiceItem(String productName, int quantity, double price, int productID) {
            this.productName = productName;
            this.quantity = quantity;
            this.price = price;
            this.productID = productID;
        }

        public String getProductName() { return productName; }
        public int getQuantity() { return quantity; }
        public double getPrice() { return price; }
        public double getTotal() { return quantity * price; }
        public int getProductID() { return productID; }
    }
}